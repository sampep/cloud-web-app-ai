import React from 'react';
import animatedLogo from '../../../assets/img/brand/animatedlogo.gif'

function RcloneLoading() {
	return (<img src={animatedLogo} alt={"Loading"}/>);
}
