/*This is used by React DND for identifying the drag source type*/
export const ItemTypes = {
    FILECOMPONENT: 'FileComponent'
}