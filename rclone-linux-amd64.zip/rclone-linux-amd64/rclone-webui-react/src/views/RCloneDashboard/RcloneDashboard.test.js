describe('Rclone Dashboard', function () {
    it('should render', function () {
        expect(1).toBe(1);
    });
});